package com.zyntrax.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZyntraxApp() }
    }
}

@Composable
fun ZyntraxApp() {
    val bg = Color(0xFF080B14)
    val panel = Color(0xFF121827)
    val purple = Color(0xFF8B5CF6)
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(ChatMessage("Olá! Eu sou o ZYNTRAX AI. Esta é uma versão demonstrativa do chat.", false)))
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().background(bg).padding(16.dp)) {
            Text("ZYNTRAX", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("INTELIGÊNCIA ARTIFICIAL", color = purple, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (msg.fromUser) purple else panel, shape = RoundedCornerShape(16.dp)) {
                            Text(msg.text, color = Color.White, modifier = Modifier.padding(14.dp))
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(panel, RoundedCornerShape(24.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(10.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    decorationBox = { inner ->
                        if (input.isEmpty()) Text("Digite sua mensagem...", color = Color.Gray)
                        inner()
                    }
                )
                Button(
                    onClick = {
                        val text = input.trim()
                        if (text.isNotEmpty()) {
                            messages = messages + ChatMessage(text, true) +
                                ChatMessage("Estou em modo de demonstração. A conexão com a IA real será adicionada pelo backend seguro.", false)
                            input = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = purple)
                ) { Text("Enviar") }
            }
        }
    }
}
